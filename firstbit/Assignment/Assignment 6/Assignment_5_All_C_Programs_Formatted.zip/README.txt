ASSIGNMENT 5 - FUNCTIONS IN C
All requested programs are separated by assignment/question/type.

Function types:
Type 1 = Without parameter, without return
Type 2 = With parameter, without return
Type 3 = Without parameter, with return
Type 4 = With parameter, with return

Assignment 1 and 2: all supplied questions are converted to all four types.
Assignment 3: Q3 (sum of a range) is excluded as a range program; the other questions are supplied in two types.
Assignment 4: Q1-Q4 are range programs and are excluded; Q5 menu-driven is supplied in the two requested types.

Compile each .c file separately.
