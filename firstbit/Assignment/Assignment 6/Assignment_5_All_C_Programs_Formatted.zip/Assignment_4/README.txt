Q1-Q4 are range programs, so they are excluded. Q5 is converted into the two required function types.
