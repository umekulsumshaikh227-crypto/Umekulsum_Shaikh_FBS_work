Q3 Sum of numbers in a given range is a range program and is excluded from Assignment 5 according to the assignment instruction.
