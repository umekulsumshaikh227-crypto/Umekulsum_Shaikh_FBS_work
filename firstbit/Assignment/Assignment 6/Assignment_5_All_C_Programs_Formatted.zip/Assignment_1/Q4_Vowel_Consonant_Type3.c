#include <stdio.h>
int check() {
    char c;
    printf("Enter character: ");
    scanf(" %c",&c);
    return c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U';
}

int main() {
    if(check()) printf("Vowel");
    else printf("Consonant");
    return 0;
}
