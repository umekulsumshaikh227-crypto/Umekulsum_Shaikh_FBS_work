#include <stdio.h>
int leap() {
    int y;
    printf("Enter year: ");
    scanf("%d",&y);
    return y%400==0 || (y%4==0 && y%100!=0);
}

int main() {
    if(leap()) printf("Leap Year");
    else printf("Not Leap Year");
    return 0;
}
