#include <stdio.h>
int palindrome() {
    int n,o,r,rev=0;
    printf("Enter 3 digit number: ");
    scanf("%d",&n);
    o=n;
    while(n>0) {
        r=n%10;
        rev=rev*10+r;
        n/=10;
    }
    return o==rev;
}

int main() {
    if(palindrome()) printf("Palindrome");
    else printf("Not Palindrome");
    return 0;
}
