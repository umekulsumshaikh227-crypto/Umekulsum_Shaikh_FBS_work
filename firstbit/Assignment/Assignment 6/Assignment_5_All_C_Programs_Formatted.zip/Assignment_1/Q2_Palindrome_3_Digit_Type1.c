#include <stdio.h>
void palindrome() {
    int n,o,r,rev=0;
    printf("Enter 3 digit number: ");
    scanf("%d",&n);
    o=n;
    while(n>0) {
        r=n%10;
        rev=rev*10+r;
        n/=10;
    }
    if(o==rev) printf("Palindrome");
    else printf("Not Palindrome");
}

int main() {
    palindrome();
    return 0;
}
