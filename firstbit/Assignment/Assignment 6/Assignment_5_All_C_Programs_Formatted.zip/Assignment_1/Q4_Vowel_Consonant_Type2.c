#include <stdio.h>
void check(char c) {
    if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U') printf("Vowel");
    else printf("Consonant");
}

int main() {
    char c;
    printf("Enter character: ");
    scanf(" %c",&c);
    check(c);
    return 0;
}
