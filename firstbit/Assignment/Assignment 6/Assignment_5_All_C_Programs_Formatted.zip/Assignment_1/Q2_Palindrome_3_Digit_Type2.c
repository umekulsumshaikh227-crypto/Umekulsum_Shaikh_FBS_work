#include <stdio.h>
void palindrome(int n) {
    int o=n,r,rev=0;
    while(n>0) {
        r=n%10;
        rev=rev*10+r;
        n/=10;
    }
    if(o==rev) printf("Palindrome");
    else printf("Not Palindrome");
}

int main() {
    int n;
    printf("Enter 3 digit number: ");
    scanf("%d",&n);
    palindrome(n);
    return 0;
}
