#include <stdio.h>
void leap(int y) {
    if(y%400==0 || (y%4==0 && y%100!=0)) printf("Leap Year");
    else printf("Not Leap Year");
}

int main() {
    int y;
    printf("Enter year: ");
    scanf("%d",&y);
    leap(y);
    return 0;
}
