#include <stdio.h>
void check() {
    char c;
    printf("Enter character: ");
    scanf(" %c",&c);
    if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u'||c=='A'||c=='E'||c=='I'||c=='O'||c=='U') printf("Vowel");
    else printf("Consonant");
}

int main() {
    check();
    return 0;
}
