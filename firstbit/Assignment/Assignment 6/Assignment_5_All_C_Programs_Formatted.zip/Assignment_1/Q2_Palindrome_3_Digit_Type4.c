#include <stdio.h>
int palindrome(int n) {
    int o=n,r,rev=0;
    while(n>0) {
        r=n%10;
        rev=rev*10+r;
        n/=10;
    }
    return o==rev;
}

int main() {
    int n;
    printf("Enter 3 digit number: ");
    scanf("%d",&n);
    if(palindrome(n)) printf("Palindrome");
    else printf("Not Palindrome");
    return 0;
}
